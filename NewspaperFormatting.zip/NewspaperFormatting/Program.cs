﻿namespace NewspaperFormatting
{
    public class Program
    {
        public static int Main(string[] args)
        {
           /* try
            {*/
            var article = new Article(new ConsoleReader());

            foreach (var page in article.Pages)
            {
                foreach (var column in page.Columns)
                {
                    foreach (var row in column.Rows)
                    {
                        Console.WriteLine(row.Line);
                    }

                    Console.WriteLine("\n");
                }

                Console.WriteLine("\n\n");
            }
            return 0;            
            /*{
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("\nExiting...\n");
                return 1;
            }*/
        }
    }
}