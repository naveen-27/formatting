﻿namespace NewspaperFormatting
{
    public static class JustifyFormatter
    {
        public static RowResponse Format(string[] words, int columnWidth, RowType rowType)
        {
            int i = 0;
            string line = "";
            int characterCount = rowType == RowType.First ? 2 : 0;

            while (i < words.Length)
            {
                string currentWord = words[i].Trim();

                if (line.Length + currentWord.Length == columnWidth)
                {
                    line += currentWord;
                    characterCount += currentWord.Length;
                    return DistributeSpaces(line, columnWidth, characterCount, rowType);
                }

                else if (line.Length + currentWord.Length + 1 < columnWidth)
                {
                    line += currentWord + " ";
                    characterCount += currentWord.Length;
                    i++;
                }
                else
                {
                    var availableSpace = columnWidth - line.Length;

                    if (availableSpace > 2)
                    {
                        var firstPartition = currentWord.Substring(0, availableSpace - 1);
                        var secondPartition = currentWord.Substring(firstPartition.Length - 1);

                        if (firstPartition.Length >= 2 && secondPartition.Length > 2)
                        {
                            line += firstPartition + (firstPartition[firstPartition.Length - 1] == '-' ? "" : "-");
                            return new RowResponse
                            {
                                Line = line,
                                WordsFormatted = i,
                                SplittedWordPart = secondPartition,
                            };
                        }
                    }

                    return DistributeSpaces(line, columnWidth, characterCount, rowType);
                }
            }

            return DistributeSpaces(line, columnWidth, characterCount, rowType);
        }

        private static RowResponse DistributeSpaces(string line, int width, int characters, RowType rowType)
        {
            string[] words = line.Trim().Split(" ");

            if (rowType == RowType.Last)
            {
                return new RowResponse
                {
                    Line = line,
                    WordsFormatted = words.Length,
                };
            }

            int length = words.Length == 1 ? 1 : words.Length - 1;
            int spaces = (width - characters) / length;

            string formattedLine = rowType == RowType.First ? "  " : "";

            for (int word = 0; word < words.Length - 1; word++)
            {
                formattedLine += words[word];

                for (int j = 0; j < spaces; j++)
                {
                    formattedLine += " ";
                }
            }

            int leftOverSpace = width - formattedLine.Length - words[words.Length - 1].Length;

            for (int j = 0; j < leftOverSpace; j++)
            {
                formattedLine += " ";
            }

            formattedLine += words[words.Length - 1];

            return new RowResponse
            {
                Line = rowType == RowType.First ? "  " + formattedLine : formattedLine,
                WordsFormatted = words.Length,
            };
        }

    }
}
