﻿namespace NewspaperFormatting
{
    public class RowResponse
    {
        public string Line { get; set; }
        public int WordsFormatted { get; set; }
        public string SplittedWordPart { get; set; }
    }

    public enum RowType
    {
        First,
        Middle,
        Last,
    }
}
