﻿namespace NewspaperFormatting
{
    public class Page
    {
        private readonly int rowsCount;
        private readonly List<int> columnWidths;
        public string[] words;

        public List<Column> Columns { get; set; }
        public int WordsUsed { get; set; }

        public Page(string[] words, List<int> columnWidths, int rowsCount)
        {
            this.words = words;
            this.columnWidths = columnWidths;
            this.rowsCount = rowsCount;
            this.Columns = new List<Column>();
            this.WordsUsed = 0;

            this.BuildPage();
        }

        private void BuildPage()
        {
            var i = 0;

            while (i < words.Length && Columns.Count < this.columnWidths.Count)
            {
                var columnWidth = this.Columns.Count > 1 ?
                                    this.columnWidths[this.Columns.Count - 1] : this.columnWidths[0];

                var column = new Column(words[i..], columnWidth, rowsCount);
                this.Columns.Add(column);

                i += column.WordsUsed;
                WordsUsed += column.WordsUsed;
            } 
        }
    }
}
