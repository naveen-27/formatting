﻿namespace NewspaperFormatting.Interfaces
{
    public interface IInput
    {
        public string[] Read();
    }
}
