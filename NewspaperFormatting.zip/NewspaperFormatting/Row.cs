﻿namespace NewspaperFormatting
{
    public class Row
    {
        public readonly string[] words;
        public readonly int width;
        public readonly RowType type;

        public string Line { get; set; }
        public int WordsUsed { get; set; }

        public Row(string[] words, int width, RowType rowType)
        {
            this.words = words;
            this.width = width;
            this.type = rowType;
            this.WordsUsed = 0;

            this.Build();

        }

        private void Build()
        {
            var formattedResponse = JustifyFormatter.Format(words, width, type);

            Line = formattedResponse.Line;
            if (formattedResponse.SplittedWordPart != null) 
            {
                words[formattedResponse.WordsFormatted] = formattedResponse.SplittedWordPart;
            }
            WordsUsed = formattedResponse.WordsFormatted;
        }
    }
}
