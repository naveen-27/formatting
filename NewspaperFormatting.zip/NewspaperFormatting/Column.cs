﻿namespace NewspaperFormatting
{
    public class Column
    {
        private readonly string[] words;
        private readonly int width;
        public int rowsCount;

        public List<Row> Rows { get; set; }
        public int WordsUsed { get; set; }

        public Column(string[] words, int width, int rowsCount)
        {
            this.words = words;
            this.width = width;
            this.rowsCount = rowsCount;
            this.WordsUsed = 0;
            Rows = new List<Row>();

            this.Build();
        }

        private void Build()
        {
            var i = 0;
            
            while (i < words.Length && Rows.Count < rowsCount)
            {
                var rowType = this.Rows.Count == 0 ?
                                    RowType.First : this.Rows.Count == this.rowsCount ?
                                                                RowType.Last : RowType.Middle;

                var row = new Row(words[i..], width, rowType);
                Rows.Add(row);

                i += row.WordsUsed;
                WordsUsed += row.WordsUsed;
            }
        }
    }
}
