﻿using NewspaperFormatting.Interfaces;

namespace NewspaperFormatting
{
    public class ConsoleReader : IInput
    {
        private const string folderPath = @"C:\Users\navee\source\repos\NewspaperFormatting\";
        public string[] Read()
        {
            var fileName = string.Empty;

            Console.Write("File: ");
            fileName = Console.ReadLine();

            if (string.IsNullOrEmpty(fileName))
            {
                throw new ArgumentNullException("File name cannot be null");
            }

            var absoluteFilePath = Path.Combine(folderPath, fileName);

            if (!File.Exists(absoluteFilePath))
            {
                throw new FileNotFoundException($"File {fileName} does not exist in folder {folderPath}");
            }

            return File.ReadAllText(absoluteFilePath).Split(" ");
        }
    }
}
