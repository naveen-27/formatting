﻿using NewspaperFormatting.Interfaces;

namespace NewspaperFormatting
{
    public class Article
    {
        private string[] articleWords;
        private int columnsCount;
        private int rowsCount;
        private int pageWidth;
        private List<int> columnWidths;
        private readonly IInput input;

        public List<Page> Pages { get; set; }

        public Article(IInput input)
        {
            this.input = input;
            columnWidths = new List<int>();
            Pages = new List<Page>();
            articleWords = input.Read();

            this.Build();
        }

        private void GetOptions()
        {
            var optionInput = string.Empty;

            Console.Write("Columns[Default - 2]: ");
            optionInput = Console.ReadLine();
            columnsCount = Int32.Parse(!string.IsNullOrEmpty(optionInput) ? optionInput : "2");

            Console.Write("Rows[Default - 20]: ");
            optionInput = Console.ReadLine();
            rowsCount = Int32.Parse(!string.IsNullOrEmpty(optionInput) ? optionInput : "20");

            Console.Write("Page Width[Default - 80]: ");
            optionInput = Console.ReadLine();
            pageWidth = int.Parse(!string.IsNullOrEmpty(optionInput) ? optionInput : "80");
        }

        private void SetColumnWidths()
        {
            var calculatedColumnWidth = pageWidth / columnsCount;

            for (int i = 0; i < columnsCount; i++)
            {
                columnWidths.Add(calculatedColumnWidth);
            }

            for (int i = 0; i < pageWidth % columnsCount; i++)
            {
                columnWidths[i] += 1;
            }
        }

        public void Build()
        {
            GetOptions();
            SetColumnWidths();

            var i = 0;

            while (i < articleWords.Length)
            {
                var page = new Page(articleWords[i..], columnWidths, rowsCount);
                Pages.Add(page);

                i += page.WordsUsed;
            }
        }
    }
}
